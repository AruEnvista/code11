package com.landmarkgroup.api.returnpolicyenquiry.service;

import com.landmarkgroup.api.returnpolicyenquiry.exception.NotFoundException;
import com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel.ExternalOrderRequest;
import com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel.*;
import com.landmarkgroup.api.returnpolicyenquiry.mapper.BusinessMapper;
import com.landmarkgroup.api.returnpolicyenquiry.repository.SalesOrderRepository;
import org.drools.core.event.DefaultAgendaEventListener;
import org.kie.api.event.rule.AfterMatchFiredEvent;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.StatelessKieSession;
import org.reactivestreams.Publisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import java.math.BigDecimal;
import java.util.Arrays;

@Service
public class ReturnPolicyValidationService {

    private BusinessMapper mapper;
    private KieContainer kieContainer;
    private SalesOrderRepository repo;

    ReturnPolicyValidationService(BusinessMapper mapper, KieContainer kieContainer,
                                  SalesOrderRepository repo) {
        this.mapper = mapper;
        this.kieContainer = kieContainer;
        this.repo = repo;
        //this.repoR = repoR;
    }
    private String sessionName = "returnPolicySession";

    public Publisher<ResponseEntity<ExternalOrderRequest>> validateOrderForReturns(String orderNumber,ExternalOrderRequest orderRequest) throws Exception {
        //SalesOrderRequest requestToOms = mapper.mapFromExternalOrderToOMSOrder(orderRequest,orderNumber);

            SalesOrderResponse order1 = new SalesOrderResponse ();
            order1.setOrderDate ( "2020-11-21T14:28:33+04:00" );
            order1.setOrderNumber ( "0090090" );
            order1.setEnterpriseCode ( "LMG_KSA" );
            order1.setSource ( "OMS" );
            order1.setDocumentType ( "1000"  );
            order1.setIsGuestUser ( "Y" );
            SalesOrderLines s = new SalesOrderLines ();
            s.setDepartmentCode ( "29" );
            s.setReturnableQuantity (  4 );
            s.setPrimeLineNumber ( "1" );
            s.setDeliveryDate ("2020-11-21T14:28:33+04:00");
            ItemDetails i1 = new ItemDetails ();
            i1.setItemIdentifier ( "Item-1009" );
            s.setItemDetails ( i1 );
            s.setDeliveryType ( "HC" );
            s.setOrderedQuantity ( 10 );


            SalesOrderLines s1 = new SalesOrderLines ();
            s1.setDepartmentCode ( "02" );
            s1.setReturnableQuantity ( 5  );
            s1.setPrimeLineNumber ( "2" );
            s1.setDeliveryDate ("2020-11-21T14:28:33+04:00");
            ItemDetails i2 = new ItemDetails ();
            i2.setItemIdentifier ( "Item-1008" );
            s1.setItemDetails ( i2 );
            s1.setDeliveryType ( "CC" );
            s1.setOrderedQuantity ( 10 );
           order1.setOrderLines ( Arrays.asList ( s, s1 ) );
            //order1.setOrderLines ( Arrays.asList ( s) );

           // repo.insert(order1).subscribe ();

        /*Mono<SalesOrderResponse> r = repo.findById ( "0090048" )
                .defaultIfEmpty ( ResponseEntity.status ( HttpStatus.NOT_FOUND ).body (  ) );
        System.out.println("Datais"+r);*/



            StatelessKieSession kieSession = kieContainer.newStatelessKieSession ( sessionName );

            Mono<SalesOrderResponse> salesOrderResponsePostApplyingRules = repo.findByOrderNumber ( orderRequest.getCustomerOrderId () )
                    .switchIfEmpty ( Mono.error (new NotFoundException ( "Order not found" )) )
                    .flatMap ( existingProduct -> {
                        existingProduct.setSource ( orderRequest.getSource () );
                        kieSession.addEventListener ( new DefaultAgendaEventListener () {

                            public void afterMatchFired(AfterMatchFiredEvent event) {
                                super.afterMatchFired ( event );
                                System.out.println ( "Rules:-" + event.getMatch ().getRule ().getName () );//prints the rule name that fires the event
                            }
                        } );
                        kieSession.execute ( mapper.validateSalesOrder ( existingProduct, orderRequest ) );
                        System.out.println ( "After rules" + existingProduct );
                        return Mono.just ( existingProduct ).log ( "Log the outPut message111:-" + existingProduct );
                    });
                /*.switchIfEmpty ( orderDAO.findByOrderNo ( orderNumber ).flatMap ( existingProduct -> {
                    kieSession.addEventListener ( new DefaultAgendaEventListener () {
                        //this event will be executed after the rule matches with the model data
                        public void afterMatchFired(AfterMatchFiredEvent event) {
                            super.afterMatchFired ( event );
                        }
                    } );
                    kieSession.execute ( mapper.validateSalesOrder ( existingProduct, orderRequest ) );
            return Mono.just ( existingProduct );
        } ).map ( o3 -> ResponseEntity.ok ( o3 ) )
                .defaultIfEmpty ( ResponseEntity.notFound ().build () ) ).log ().orElseThrow(() -> new NotFoundException (" Order not found "));*/
   /*ServiceCommandInterface serviceCommandInterface = new GetOrderDetailsCommand(new String("URL"));
InvokeService service = new InvokeService(serviceCommandInterface);
service.ExecuteRequest();*/


            //Mocking return details
            OmsReturnOrders returnOrders1 = new OmsReturnOrders ();
            OmsReturnOrder oms = new OmsReturnOrder ();
            oms.setReturnOrderNumber ( "0000001" );
            oms.setEnterpriseCode ( "LMG_Kuwait" );
            oms.setRefundInitiatedFlag ( "N" );
            oms.setSource ( "Hybris" );
            oms.setReturnOrderDate ( "2019-11-21T14:28:33+04:00" );
            oms.setReturnOrderStatus ( "Created" );
            ReturnOrderLines line = new ReturnOrderLines ();
            line.setItemIdentifier ( "Item-1009" );
            line.setReturnQuantity ( new BigDecimal ( 2 ) );
            line.setLineStatus ( "Created" );
            oms.setOrderLines ( Arrays.asList ( line ) );

            OmsReturnOrder oms1 = new OmsReturnOrder ();
            oms1.setReturnOrderNumber ( "0000002" );
            oms1.setEnterpriseCode ( "LMG_KSA" );
            oms1.setRefundInitiatedFlag ( "N" );
            oms1.setSource ( "Hybris" );
            oms1.setReturnOrderDate ( "2019-11-21T14:28:33+04:00" );
            oms1.setReturnOrderStatus ( "Return Created" );
            ReturnOrderLines line1 = new ReturnOrderLines ();
            line1.setItemIdentifier ( "Item-1008" );
            line1.setReturnQuantity ( new BigDecimal ( 2 ) );
            line1.setLineStatus ( "Created" );
            oms1.setOrderLines ( Arrays.asList ( line1 ) );

            returnOrders1.setReturnOrders ( Arrays.asList ( oms, oms1 ) );
            //repoR.insert ( returnOrders1.getReturnOrders () );


        /*salesOrderResponsePostApplyingRules.flatMap ( nextObject-> {
            if(nextObject.isRTS ()){
                //prepare doc(use same requestToOms object)
                //call return API

                Flux<OmsReturnOrder> returnResponsePostApplyingRules = repoR.findByReturnOrderNumber ( orderRequest.getCustomerOrderId () )
                        .flatMap ( returnOrders -> {
                            mapper.validateReturnOrder ( returnOrders, nextObject);
                            System.out.println ( "After rules for returnOrder" + returnOrders );
                            return Flux.just ( returnOrders ).log ( "Log the outPut message of return:-" + returnOrders );
                        } );
            }
            return salesOrderResponsePostApplyingRules;
        });*/

            Mono<SalesOrderResponse> order = salesOrderResponsePostApplyingRules.flatMap ( nextObject -> {
                if (nextObject.isRTS ()) {
                    mapper.validateReturnOrder ( returnOrders1, nextObject );
                }
                return Mono.just ( nextObject ).log ( "Log the Return outPut message111:-" + nextObject );
            } );


            /*return ExternalSystemOrderResponse*/
            Mono<ExternalOrderRequest> externalOrderResponse = mapper.mapFromOMSOrderToExternalOrder ( order, orderRequest );

            return externalOrderResponse.map ( o1 -> ResponseEntity.status ( HttpStatus.OK ).body ( o1 ) )
                    .defaultIfEmpty ( ResponseEntity.status ( HttpStatus.NOT_FOUND ).build () );
        }

}
