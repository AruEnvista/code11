package com.landmarkgroup.api.returnpolicyenquiry.model.omsorderrequestandresponsemodel;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Slf4j
@Document("returnOrderDB")
public class OmsReturnOrders {

    @Field("return_orders")
    private List<OmsReturnOrder> returnOrders;

}
