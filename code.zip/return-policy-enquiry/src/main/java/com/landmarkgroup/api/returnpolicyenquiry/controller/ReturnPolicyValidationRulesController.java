package com.landmarkgroup.api.returnpolicyenquiry.controller;

import com.landmarkgroup.api.returnpolicyenquiry.model.externalrequestandresponsemodel.ExternalOrderRequest;
import com.landmarkgroup.api.returnpolicyenquiry.service.ReturnPolicyValidationService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.reactivestreams.Publisher;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Map;

@RestController
@RequestMapping("/v3/customer-orders")
public class ReturnPolicyValidationRulesController {

    private ReturnPolicyValidationService returnPolicyValidationService;

    ReturnPolicyValidationRulesController(ReturnPolicyValidationService returnPolicyValidationService) {
        this.returnPolicyValidationService = returnPolicyValidationService;
    }

    /**
     * The Return Policy Validation Enquiry Rules
     *
     * @param orderNumber   - customer-order-id
     * @param orderRequest - payload
     * @return ExternalOrderReturnResponse
     */
    @PostMapping("/{customer-order-id}/events/return-policy-enquiry")
    @ApiOperation(value = "Refund Enquiry API")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "Success",response=ExternalOrderRequest.class,
            responseContainer = "ResponseEntity" ),
            @ApiResponse(code = 500, message = "Internal server error"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 404, message = "Not Found")
    })
    public Publisher<ResponseEntity<ExternalOrderRequest>> returnPolicyValidation(@Valid @PathVariable("customer-order-id") String orderNumber,
                                                                                  @Valid @RequestBody ExternalOrderRequest orderRequest, @RequestHeader Map<String,String> requestHeader) throws Exception {
        return returnPolicyValidationService.validateOrderForReturns (orderNumber,orderRequest);
    }
}

