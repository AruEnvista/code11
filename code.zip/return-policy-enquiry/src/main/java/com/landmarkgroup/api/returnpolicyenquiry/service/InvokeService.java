package com.landmarkgroup.api.returnpolicyenquiry.service;

import java.net.URISyntaxException;

public class InvokeService {

    private ServiceCommandInterface serviceCommandInterface;

    public InvokeService(ServiceCommandInterface serviceCommand) {
        this.serviceCommandInterface = serviceCommand;
    }

    public Object ExecuteRequest() throws URISyntaxException {
        System.out.println("Start: Service Request");
        return serviceCommandInterface.Execute();
    }
}
